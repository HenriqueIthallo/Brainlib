import sqlite3

class PretrainingDB:
  def __init__(self, db_path="pretraining.db"):
    self.db_path = db_path
    self.conn = sqlite3.connect(self.db_path)
    self.cursor = self.conn.cursor()
    self._initialize_db()

  def _initialize_db(self):
    self.cursor.execute('''
      CREATE TABLE IF NOT EXISTS conversation_pairs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        input_text TEXT NOT NULL,
        response_text TEXT NOT NULL
      )
    ''')
    self.conn.commit()

  def add_conversation_pair(self, input_text, response_text):
    self.cursor.execute('''
      INSERT INTO conversation_pairs (input_text, response_text)
      VALUES (?, ?)
    ''', (input_text, response_text))
    self.conn.commit()

  def get_all_pairs(self):
    self.cursor.execute('SELECT input_text, response_text FROM conversation_pairs')
    return self.cursor.fetchall()

  def close(self):
    self.conn.close()